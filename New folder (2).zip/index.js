import mongoose from 'mongoose';
import AWS from 'aws-sdk';

const s3 = new AWS.S3();

export const handler = async (event) => {
  await mongoose.connect('mongodb+srv://mongo:mongo@mongo.3tx63.mongodb.net/?retryWrites=true&w=majority&appName=mongo');

  const collections = await mongoose.connection.db.listCollections().toArray();

  for (const collection of collections) {
    const data = await mongoose.connection.db.collection(collection.name).find().toArray();
    const jsonData = JSON.stringify(data);
    const params = {
      Bucket: 'your-s3-bucket',
      Key: `backup/${collection.name}.json`,
      Body: jsonData,
      ContentType: 'application/json',
    };

    await s3.putObject(params).promise();
  }

  await mongoose.connection.close();
};
